#include <stdio.h>
#include <stdlib.h>
// #include "SMTPManager.h"

int main(int argc, char *argv[]) {

  print("hello world\n");
	return 0;
}
